#!/bin/bash
pip install psutil scipy numpy pandas matplotlib
